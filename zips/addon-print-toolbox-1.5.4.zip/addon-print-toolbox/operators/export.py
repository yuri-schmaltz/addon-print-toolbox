# SPDX-License-Identifier: GPL-3.0-or-later
# SPDX-FileCopyrightText: 2013-2023 Campbell Barton
# SPDX-FileCopyrightText: 2016-2025 Mikhail Rachinskiy

# Export wrappers and integration with external tools.

import bpy
from bpy.app.translations import pgettext_data as data_
from bpy.app.translations import pgettext_tip as tip_
from bpy.props import StringProperty
from bpy.types import Image, Material, Object, Operator
from ..core.compat import filtered_operator_kwargs, is_3mf_export_available, operator_exists
from ..core.runtime import logger


class EXPORT_SCENE_OT_export(Operator):
    bl_idname = "export_scene.print3d_export"
    bl_label = "Export"
    bl_description = "Export selected objects using settings below"
    bl_options = {"INTERNAL"}

    filepath: StringProperty(
        subtype="FILE_PATH",
        options={"SKIP_SAVE", "HIDDEN"},
    )

    @classmethod
    def poll(cls, context):
        return bool(context.selected_objects)

    def execute(self, context):
        unit = context.scene.unit_settings
        props = context.scene.print3d_toolbox

        global_scale = unit.scale_length if (unit.system != "NONE" and props.use_scene_scale) else 1.0

        if (
            props.use_assembly_tolerance
            and props.apply_tolerance_on_export
            and len(context.selected_objects) > 1
        ):
            dims = [max(obj.dimensions) for obj in context.selected_objects if obj.type == "MESH"]
            if dims:
                max_dim = max(dims)
                if max_dim > 0.0:
                    tolerance_scale = max(0.0, 1.0 - (props.assembly_tolerance / max_dim))
                    global_scale *= tolerance_scale

        path_mode = "COPY" if props.use_copy_textures else "AUTO"
        filepath = bpy.path.ensure_ext(self.filepath, f".{props.export_format.lower()}")

        # this can fail with strange errors,
        # if the dir can't be made then we get an error later.
        if not _ensure_export_dir(filepath, self.report):
            return {"CANCELLED"}

        # Non-destructive decimation
        decimate_modifiers = []
        if props.use_export_decimate and props.export_decimate_ratio < 1.0:
            for obj in context.selected_objects:
                if obj.type == "MESH":
                    mod = obj.modifiers.new(name="__print3d_decimate__", type="DECIMATE")
                    mod.ratio = props.export_decimate_ratio
                    decimate_modifiers.append((obj, mod))

        try:
            if props.export_format == "STL":
                ret = bpy.ops.wm.stl_export(
                    filepath=filepath,
                    ascii_format=props.use_ascii_format,
                    global_scale=global_scale,
                    apply_modifiers=True,
                    export_selected_objects=True,
                )
            elif props.export_format == "PLY":
                ret = bpy.ops.wm.ply_export(
                    filepath=filepath,
                    ascii_format=props.use_ascii_format,
                    global_scale=global_scale,
                    export_uv=props.use_uv,
                    export_normals=props.use_normals,
                    export_colors="SRGB" if props.use_colors else "NONE",
                    apply_modifiers=True,
                    export_selected_objects=True,
                    export_attributes=False,
                )
            elif props.export_format == "OBJ":
                ret = bpy.ops.wm.obj_export(
                    filepath=filepath,
                    global_scale=global_scale,
                    export_uv=props.use_uv,
                    export_normals=props.use_normals,
                    export_colors=props.use_colors,
                    export_materials=props.use_copy_textures,
                    path_mode=path_mode,
                    apply_modifiers=True,
                    export_selected_objects=True,
                )
            elif props.export_format == "3MF":
                ret = _export_3mf(filepath, global_scale, props, self.report)
            else:
                assert 0
        finally:
            # Clean up modifiers
            for obj, mod in decimate_modifiers:
                obj.modifiers.remove(mod)

        # for formats that don't support images
        if path_mode == "COPY" and props.export_format in {"STL", "PLY"}:
            _image_copy_guess(filepath, context.selected_objects, self.report)

        if "FINISHED" in ret:
            self.report({"INFO"}, tip_("Exported: {!r}").format(filepath))
            return {"FINISHED"}

        if props.export_format == "3MF" and not is_3mf_export_available():
            self.report({"WARNING"}, "3MF export skipped: exporter unavailable in this Blender build")
        else:
            self.report({"ERROR"}, "Export failed")
        return {"CANCELLED"}

    def invoke(self, context, event):
        import re
        from pathlib import Path

        if not context.selected_objects:
            return {"CANCELLED"}

        props = context.scene.print3d_toolbox

        if context.object:
            ob = context.object
        else:
            ob = context.selected_objects[0]

        ob_name = re.sub(r'[\\/:*?"<>|]', "", ob.name)

        if bpy.data.is_saved:
            blend_name = Path(bpy.data.filepath).stem
        else:
            blend_name = data_("Untitled")

        # Ensure blend_name is also safe just in case
        blend_name = re.sub(r'[\\/:*?"<>|]', "", blend_name)
        filename = f"{blend_name}-{ob_name}.{props.export_format.lower()}"

        if bpy.data.is_saved or (props.export_path and not props.export_path.startswith("//")):
            self.filepath = str(Path(bpy.path.abspath(props.export_path)) / filename)
        else:
            self.filepath = str(Path.home() / filename)

            wm = context.window_manager
            wm.fileselect_add(self)

            return {"RUNNING_MODAL"}

        return self.execute(context)


class WM_OT_print3d_preset_add(Operator):
    bl_idname = "wm.print3d_preset_add"
    bl_label = "Add Export Preset"
    bl_description = "Add a new export preset with current settings"
    bl_options = {"INTERNAL", "UNDO"}

    name: StringProperty(name="Name", default="New Preset")

    def execute(self, context):
        from .. import __package__ as base_package

        addon = context.preferences.addons.get(base_package)
        if addon is None:
            return {"CANCELLED"}

        prefs = addon.preferences
        props = context.scene.print3d_toolbox

        preset = prefs.export_presets.add()
        preset.name = self.name
        preset.export_format = props.export_format
        preset.use_ascii_format = props.use_ascii_format
        preset.use_scene_scale = props.use_scene_scale
        preset.use_copy_textures = props.use_copy_textures
        preset.use_uv = props.use_uv
        preset.use_normals = props.use_normals
        preset.use_colors = props.use_colors
        preset.use_3mf_materials = props.use_3mf_materials
        preset.use_3mf_units = props.use_3mf_units
        preset.use_export_decimate = props.use_export_decimate
        preset.export_decimate_ratio = props.export_decimate_ratio

        # Update the active preset selection
        props.export_preset = str(len(prefs.export_presets) - 1)

        self.report({"INFO"}, tip_("Preset added: {}").format(self.name))
        return {"FINISHED"}

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self)


class WM_OT_print3d_preset_remove(Operator):
    bl_idname = "wm.print3d_preset_remove"
    bl_label = "Remove Export Preset"
    bl_description = "Remove the selected export preset"
    bl_options = {"INTERNAL", "UNDO"}

    def execute(self, context):
        from .. import __package__ as base_package

        addon = context.preferences.addons.get(base_package)
        if addon is None:
            return {"CANCELLED"}

        prefs = addon.preferences
        props = context.scene.print3d_toolbox

        if not props.export_preset:
            return {"CANCELLED"}

        index = int(props.export_preset)
        if index < 0 or index >= len(prefs.export_presets):
            return {"CANCELLED"}

        name = prefs.export_presets[index].name
        prefs.export_presets.remove(index)

        # Clear selection
        props.export_preset = ""

        self.report({"INFO"}, tip_("Preset removed: {}").format(name))
        return {"FINISHED"}


def _image_get(mat: Material) -> Image | None:
    from bpy_extras import node_shader_utils

    if mat.use_nodes:
        mat_wrap = node_shader_utils.PrincipledBSDFWrapper(mat)
        base_color_tex = mat_wrap.base_color_texture
        if base_color_tex and base_color_tex.image:
            return base_color_tex.image


def _image_copy_guess(filepath: str, objects: list[Object], report=None) -> None:
    # 'filepath' is the path we are writing to.
    image = None
    mats = set()

    for obj in objects:
        for slot in obj.material_slots:
            if slot.material:
                mats.add(slot.material)

    for mat in mats:
        image = _image_get(mat)
        if image is not None:
            break

    if image is not None:
        import os
        import shutil

        imagepath = bpy.path.abspath(image.filepath, library=image.library)
        if os.path.exists(imagepath):
            filepath_noext = os.path.splitext(filepath)[0]
            ext = os.path.splitext(imagepath)[1]

            imagepath_dst = filepath_noext + ext
            logger.info("Copying texture %r -> %r", imagepath, imagepath_dst)

            try:
                shutil.copy(imagepath, imagepath_dst)
            except Exception as exc:
                if report is not None:
                    report({"WARNING"}, f"Texture copy failed: {exc}")
                logger.exception("Error copying texture during export")


def _ensure_export_dir(filepath: str, report) -> bool:
    from pathlib import Path

    try:
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        report({"ERROR"}, f"Cannot create export directory: {exc}")
        return False

    return True


def _export_3mf(filepath: str, global_scale: float, props, report):
    kwargs_common = {
        "filepath": filepath,
        "global_scale": global_scale,
        "use_scene_unit": props.use_3mf_units,
        "export_materials": props.use_3mf_materials,
        "apply_modifiers": True,
        "export_selected_objects": True,
        # Names used by some legacy/new exporters.
        "use_selection": True,
        "selected_objects_only": True,
    }

    for module_name, op_name in (("export_scene", "threemf"), ("wm", "threemf_export")):
        if not operator_exists(module_name, op_name):
            continue

        op = getattr(getattr(bpy.ops, module_name), op_name)
        kwargs = filtered_operator_kwargs(op, kwargs_common)
        return op(**kwargs)

    report(
        {"WARNING"},
        "3MF exporter is unavailable in this Blender build. Use STL/OBJ/PLY or install 3MF support.",
    )
    return {"CANCELLED"}
